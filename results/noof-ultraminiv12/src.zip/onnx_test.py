# import onnxruntime as ort
import json
import sys
import os
import time
import cv2
import numpy as np
import onnxruntime as ort
from image import *
from PIL import Image
 
model="test-infer/noof1280.onnx"
path=sys.argv[1]
#Preprocess the image
img = cv2.imread(path)
# img = np.dot(img[...,:3], [0.299, 0.587, 0.114])
# img = cv2.resize(img, dsize=(28, 28), interpolation=cv2.INTER_AREA)
# img.resize((1, 1, 28, 28))
data = img.astype('float32') / 255.0
# print(data.shape)
session = ort.InferenceSession(model, providers=['TensorrtExecutionProvider'])
# print(np.min(data), np.max(data))
inp = {}
inp[session.get_inputs()[0].name] = data.transpose((2, 0, 1)).reshape((1, 3, 720, 1280))
for element in session.get_inputs()[1:]:
    inp[element.name] = np.zeros(element.shape).astype('float32')
output_name = session.get_outputs()[0].name
# print(session.get_outputs()[0])
# #print(input_name)
# #print(output_name)
 
result = session.run([output_name], inp)[0].squeeze(0).transpose((1, 2, 0))
# print(np.min(result), np.max(result))
# image = Image.fromarray(np.clip(result * 255, 0, 255).astype(np.uint8))
# image.save("output_image.png")
# save_image("test.png", )
