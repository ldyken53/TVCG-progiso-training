from PIL import Image
import os
import numpy as np
from image import *

def replace_red_with_white(image_path, output_path):
    png_files = [f for f in os.listdir(image_path) if f.lower().endswith(".png")]
    i = 0
    for f in png_files:
        # Open the image
        img = Image.open(os.path.join(image_path, f))

        # Get the width and height of the image
        width, height = img.size

        # Create a new image with the same size and initialize it with a white background

        if "ref" in f:
            img.save(os.path.join(output_path, f))
        else:
            img_array = np.array(img)

            # Define a mask for red pixels
            red_mask = (img_array[:, :, 0] > 150) & (img_array[:, :, 1] < 100) & (img_array[:, :, 2] < 100)

            # Set red pixels to white
            img_array[red_mask] = [255, 255, 255, 255]

            # Create a new image from the modified NumPy array
            new_img = Image.fromarray(img_array)

            # Save the modified image
            new_img.save(os.path.join(output_path, f))
        i += 1
        if i % 1000 == 0:
            print(i)

    exr_files = [f for f in os.listdir(image_path) if f.lower().endswith(".exr")]
    i = 0
    for f in exr_files:
        # Open the image
        img = load_image(os.path.join(image_path, f), num_channels=3)

        # Create a new image with the same size and initialize it with a white background

        if "ref" in f:
            save_image(os.path.join(output_path, f), img)
        else:
            # Define a mask for red pixels
            red_mask = (img[:, :, 0] > (150 / 255)) & (img[:, :, 1] < (100 / 255)) & (img[:, :, 2] < (100 / 255))

            # Set red pixels to white
            img[red_mask] = [255, 255, 255]
            print(f)
            save_image(os.path.join(output_path, f), img)
        i += 1
        if i % 1000 == 0:
            print(i)

if __name__ == "__main__":
    input_path = "data/finchame/95"
    output_path = "data/finchamew/95"

    replace_red_with_white(input_path, output_path)