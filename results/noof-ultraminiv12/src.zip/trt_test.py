
import os

# This sample uses an ONNX ResNet50 Model to create a TensorRT Inference Engine
import random
import sys

import numpy as np

import tensorrt as trt
from PIL import Image
import common
import cv2
import time

class ModelData(object):
    MODEL_PATH = "noof1920.onnx"
    INPUT_SHAPE = (3, 1088, 1920)
    # We can convert TensorRT data types to numpy types with trt.nptype()
    DTYPE = trt.float32


# You can set the logger severity higher to suppress messages (or lower to display more messages).
TRT_LOGGER = trt.Logger(trt.Logger.WARNING)

# The Onnx path is used for Onnx models.
def build_engine_onnx(model_file):
    builder = trt.Builder(TRT_LOGGER)
    network = builder.create_network(common.EXPLICIT_BATCH)
    config = builder.create_builder_config()
    parser = trt.OnnxParser(network, TRT_LOGGER)

    config.max_workspace_size = common.GiB(2)
    # Load the Onnx model and parse it in order to populate the TensorRT network.
    with open(model_file, "rb") as model:
        if not parser.parse(model.read()):
            print("ERROR: Failed to parse the ONNX file.")
            for error in range(parser.num_errors):
                print(parser.get_error(error))
            return None
    return builder.build_engine(network, config)


def load_normalized_test_case(test_image, pagelocked_buffer):
    # Converts the input image to a CHW Numpy array
    def normalize_image(image):
        # Resize, antialias and transpose the image to CHW.
        c, h, w = ModelData.INPUT_SHAPE
        image_arr = (
            image
            .transpose([2, 0, 1])
            .reshape((1, c, h, w))
            .astype(trt.nptype(ModelData.DTYPE))
            .ravel()
        )
        # print(np.min(image_arr), np.max(image_arr))
        return (image_arr / 255.0)

    # Normalize the image and copy to pagelocked memory.
    np.copyto(pagelocked_buffer, normalize_image(cv2.imread(test_image)))
    return test_image


def main():
    # Set the data path to the directory that contains the trained models and test images for inference.
    find_files = [f"m{i + 1}.png" for i in range(10)]
    find_files.append(ModelData.MODEL_PATH)
    _, data_files = common.find_sample_data(
        description="Runs a ResNet50 network with a TensorRT inference engine.",
        subfolder="test-infer",
        find_files=find_files,
    )
    # Get test images, models and labels.
    test_images = data_files[:10]
    onnx_model_file = data_files[10]

    # Build a TensorRT engine.
    engine = build_engine_onnx(onnx_model_file)
    print(engine)
    # Inference is the same regardless of which parser is used to build the engine, since the model architecture is the same.
    # Allocate buffers and create a CUDA stream.
    inputs, outputs, bindings, stream = common.allocate_buffers(engine)
    # Contexts are used to perform inference.
    context = engine.create_execution_context()
    print(context)

    # Load a normalized test case into the host input page-locked buffer.
    # test_image = random.choice(test_images)
    times = []
    for i in range(101):
        for test_image in test_images:
            test_case = load_normalized_test_case(test_image, inputs[0].host)
            start = time.time()
            trt_outputs = common.do_inference_v2(context, bindings=bindings, inputs=inputs, outputs=outputs, stream=stream)
            end = time.time()
            if (i != 0):
                times.append((end - start) * 1000)
    print(f"Average time: {np.mean(times)}")
    # for e in trt_outputs:
    #     print(e.shape)
    result = trt_outputs[5]
    print(np.min(result), np.max(result))

    c, h, w = ModelData.INPUT_SHAPE
    test = np.reshape(result, (c, h, w)).transpose((1, 2, 0))
    out_image = Image.fromarray(np.clip(test * 255, 0, 255).astype(np.uint8))
    out_image.save("output_image.png")
    common.free_buffers(inputs, outputs, stream)


if __name__ == "__main__":
    main()